Social Media
============

Designer: Creative Corp (https://www.iconfinder.com/CreativeCorp)
License: Free for commercial use
